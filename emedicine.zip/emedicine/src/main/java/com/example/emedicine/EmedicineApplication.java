package com.example.emedicine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmedicineApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmedicineApplication.class, args);
	}

}
