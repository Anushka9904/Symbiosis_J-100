package com.example.emedicine.repository;
import com.example.emedicine.model.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CartItemRepository extends JpaRepository<CartItem, Long>{

}




